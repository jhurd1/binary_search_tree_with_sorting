/***********************************************************************
 * Module:
 *    Week 11, Sort Select
 *    Brother Helfrich, CS 235
 * Author:
 *    Daniel Perez, Benjamin Dyas, Jamie Hurd
 * Summary:
 *    This program will implement the Selection Sort
 ************************************************************************/

#ifndef SORT_SELECTION_H
#define SORT_SELECTION_H

/********************************************
 * FUNCTION:  swapSelection
 * RETURNS:   void
 * PARAMETER: int iCheck, T array[]
 ********************************************/
template <class T>
void swapSelection(T * iLargest, T * iPivot)
{  
    T temp = *iLargest; // swap two items if out of order
    *iLargest = *iPivot;
    *iPivot = temp;
    //array[iLargest] = temp2;
    //array[iPivot] = temp1;
    //array[iLargest] = temp2;
}

/********************************************
 * FUNCTION:    sortSelection
 * RETURNS:     void
 * PARAMETER:   int iCheck, T array[]
 * DESCRIPTION: Perform the selection sort
 ********************************************/
template <class T>
void sortSelection(T array[], int num)
{
   int iLargest = 0;

   for (int iPivot = 0; iPivot < num - 1; iPivot++)
   {
      iLargest = iPivot;
      for (int j = iPivot + 1; j < num; j++)
      {
         if (array[j] < array[iLargest])
         {
            iLargest = j;
         }
      }
      //swap (&array[iLargest], &array[i]);
      swapSelection (&array[iLargest], &array[iPivot]);
   }
   
   // FOR DISCUSSION (FROM PSEUDOCODE)
   //  for (int iPivot = num - 1; iPivot > 1; iPivot--) // iPivot represents the last item
   //  {
   //      int iLargest = 0; //the start of the array
   //      for (int iCheck = 1; iCheck < iPivot - 1; iCheck++) // increments unto the end of the array
   //      {
   //          if (array[iLargest] <= array[iCheck]) // compare the first two
   //          {
   //              iLargest = iCheck; // previous item assigned to next item
   //          }
   //      }
   //      if (array[iLargest] > array[iPivot]) 
   //      {
   //          swapSelection (iLargest, iPivot, array);
   //      }
   //  }
}


#endif // SORT_SELECTION_H
