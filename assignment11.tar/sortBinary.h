/***********************************************************************
 * Module:
 *    Week 11, Sort Binary
 *    Brother Helfrich, CS 235
 * Author:
 *    <your name>
 * Summary:
 *    This program will implement the Binary Tree Sort
 ************************************************************************/

#ifndef SORT_BINARY_H
#define SORT_BINARY_H

#include "bst.h"
#include <cassert>

/*****************************************************
 * SORT BINARY
 * Perform the binary tree sort
 ****************************************************/
template <class T>
void sortBinary(T array[], int num)
{
   custom::BST<T> tree;

   for(int i = 0; i < num; i++)
   {
      tree.insert(array[i]);
   }

   int j = 0;
   typename custom::BST<T>::iterator it;
   for (it = tree.begin(); it != tree.end(); it++, j++)
      array[j] = *it;
}

#endif // SORT_BINARY_H
