/***********************************************************************
 * Module:
 *    Week 11, Sort Heap
 *    Brother Helfrich, CS 235
 * Author:
 *    Daniel Perez, Benjamin Dyas, Jamie Hurd
 * Summary:
 *    This program will implement the Heap Sort
 ************************************************************************/

#ifndef SORT_HEAP_H
#define SORT_HEAP_H

namespace custom
{
/********************************************
 * CLASS: HEAP
 ********************************************/
template <class T>
class sortHeap
{
public:
    //constructor
    sortHeap(T array[], int num);
    
    // standard HEAP interfaces
    void heapSort (T array[], int num); // changed for testing
    T    getMax();
    void deleteMax();
    void heapify (T array[], int num, int i); // added for testing
    
private:
    int num = sizeof (array) / sizeof (array[0]); //changed to accommodate testing
    void percolateDown(int index);
    void swap (int & i1, int & i2);
    T   array[];
};

/********************************************
* FUNCTION: HEAPIFY
* PARAMETER:   array, array size
* adapted from www.geeksforgeeks.org/heap-sort
********************************************/
template<class T>
void sortHeap<T>::heapify (T array[], int num, int i)
{
    int max = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;
    
    if (l < num && array[l] > array[max])
    {
        max = 1;
    }
    if (r < num && array[r] > array[max])
    {
        max = r;
    }
    if (max != i)
    {
        std::swap (array[i], array[max]);
        heapify (array, num, max);
    }
}

/********************************************
* FUNCTION: HEAP
* PARAMETER:   array, array size
* adapted from www.geeksforgeeks.org/heap-sort
********************************************/
template<class T>
void sortHeap<T>::heapSort(T array[], int num)
{
    for (int i = num / 2 - 1; i >= 0; i--)
    {
        heapify (array, num, i);
    }
    for (int i = num - 1; i > 0; i--)
    {
        heapify (array, i, 0);
    }
}// changed for testing

/********************************************
 * CONSTRUCTOR: HEAP
 * PARAMETER:   array, array size
 ********************************************
template <class T>
Heap<T>::Heap(T arrayInput[], int num)
{
    this->array[num];
    std::copy(arrayInput, arrayInput+num, this->array);
    this->num = num;
    for(int index = num / 2; index > 1; index--)
    {
        percolateDown(index);
    }
}

********************************************
 * FUNCTION:  PERCOLATEDOWN
 * RETURNS:   void
 * PARAMETER: int iCheck, T array[]
 ********************************************
template <class T>
void custom::Heap<T>::percolateDown(int index)
{
    int indexLeft = index * 2;
    int indexRight = indexLeft + 1;
    
    if (indexRight <= num &&
        array[indexRight] > array[indexLeft]&&
        array[indexRight] > array[index])
    {
        swap (index, indexRight);
        percolateDown (indexRight);
    } else if (indexLeft <= num && array[indexLeft] > array[index])
    {
        swap (index, indexLeft);
        percolateDown (indexLeft);
    }
}

********************************************
 * FUNCTION:  SORT
 * RETURNS:   void
 * PARAMETER: N/A
 ********************************************
template <class T>
void custom::Heap<T>::sort()
{
    while (num > 1)
    {
        int one = 1;
        swap (one, num);
        num--;
        percolateDown (1);
    }
}

********************************************
 * FUNCTION:  SWAP
 * RETURNS:   void
 * PARAMETER: int & i1, int & i2
 ********************************************
template <class T>
void custom::Heap<T>::swap(int & i1, int & i2)
{
    
    int temp = i1;
    i1 = i2;
    i2 = temp;
    
}
} // namespace custom

*****************************************************
 * SORT HEAP
 * Perform the heap sort
 ****************************************************
template <class T>
void sortHeap(T array[], int num)
{
    custom::Heap<T> h (array, num);
    h.sort();
}*/


#endif // SORT_HEAP_H
