/***********************************************************************
 * Module:
 *    Week 11, Sort Merge
 *    Brother Helfrich, CS 235
 * Author:
 *    Daniel Perez, Benjamin Dyas, Jamie Hurd
 * Summary:
 *    This program will implement the Merge Sort
 ************************************************************************/

#ifndef SORT_MERGE_H
#define SORT_MERGE_H
// C++ program for Merge Sort
#include <iostream>
using namespace std;
/*****************************************************
 * SORTMERGE
 * Perform the merge sort
 ****************************************************/

// Merges two subarrays of arr[].
// First subarray is arr[l..m]
// Second subarray is arr[m+1..r]

template <class T>
void merge(T arr[], int l, int m, int r)
{
	int n1 = m - l + 1;
	int n2 = r - m;

	// Create temp arrays
	T L[n1], R[n2];

	// Copy data to temp arrays L[] and R[]
	for (int i = 0; i < n1; i++)
		L[i] = arr[l + i];
	for (int j = 0; j < n2; j++)
		R[j] = arr[m + 1 + j];

	// Merge the temp arrays back into arr[l..r]

	// Initial index of first subarray
	int i = 0;

	// Initial index of second subarray
	int j = 0;

	// Initial index of merged subarray
	int k = l;

	while (i < n1 && j < n2) 
   {
		if ((L[i] < R[j]) || (L[i] == R[j]))
      {
			arr[k] = L[i];
			i++;
		}
		else 
      {
			arr[k] = R[j];
			j++;
		}
		k++;
	}

	// Copy the remaining elements of
	// L[], if there are any
	while (i < n1) 
   {
		arr[k] = L[i];
		i++;
		k++;
	}

	// Copy the remaining elements of
	// R[], if there are any
	while (j < n2) 
   {
		arr[k] = R[j];
		j++;
		k++;
	}
}

// l is for left index and r is
// right index of the sub-array
// of arr to be sorted */
template <class T>
void mergeSort(T arr[], int l, int r)
{  
	if(l >= r)
   {
		return;//returns recursively
	}
	int m = (l + r - 1) / 2;
	mergeSort (arr, l, m);
	mergeSort (arr, m+1, r);
	merge (arr, l, m, r);
}


template <class T>
void sortMerge(T array[], int num)
{
   //int arr_size = sizeof(arr) / sizeof(arr[0]);

	mergeSort(array, 0, num - 1);
   
}


// // UTILITY FUNCTIONS
// // Function to print an array
// void printArray(int A[], int size)
// {
// 	for (int i = 0; i < size; i++)
// 		cout << A[i] << " ";
// }

// // Driver code
// int main()
// {
// 	T arr[] = { 12, 11, 13, 5, 6, 7 };
// 	int arr_size = sizeof(arr) / sizeof(arr[0]);

// 	cout << "Given array is \n";
// 	printArray(arr, arr_size);

// 	mergeSort(arr, 0, arr_size - 1);

// 	cout << "\nSorted array is \n";
// 	printArray(arr, arr_size);
// 	return 0;
// }

// This code is contributed by Mayank Tyagi







// template <class T>
// void merge(T destination[], T source1[], int size1, T source2[], int size2, int iDestination)
// {
//    int i1 = 0;
//    int i2 = 0;
   
//    // int destinationSize = size1 + size2 + iDestination;
//    // for(; iDestination < destinationSize; iDestination++)
//    //  {
       
//    //      if (i1 <= size1 && ( (i2 == size2) || (source1[i1] < source2[i2]) ) )
//    //      {
//    //          destination[iDestination] = source1[i1++];
//    //      }
//    //      else
//    //      {
//    //         destination[iDestination] = source2[i2++];
//    //      }
      
//    //  }

//     while(i1 < size1 && i2 < size2)
//    {
//       if( ((source1[i1] < source2[i2]) || (source1[i1] == source2[i2]))  )
//       {
//          destination[iDestination] = source1[i1];
//          i1++;
//       }
//       else if ( source1[i1] > source2[i2] )
//       {
//          destination[iDestination] = source2[i2];
//          i2++;
//       }
//       iDestination++;
//    }

//    while (i1 < size1)
//    {
//       destination[iDestination] = source1[i1];
//       iDestination++;
//       i1++;
//    }

//    while (i2 < size2)
//    {
//       destination[iDestination] = source2[i2];
//       iDestination++;
//       i2++;
//    }
// }

// /*****************************************************
//  * SORTMERGE
//  * Perform the merge sort
//  ****************************************************/
// template <class T>
// void sortMerge(T array[], int num)
// {
//    T sourceArr[num];
//    std::copy(array, array+num, sourceArr);

//    T destinationArr[num];

//    T * source = sourceArr;
//    T * destination = destinationArr;
   
//    int numIterations;
   
//    do {
//       numIterations = 0;
      
//       int iBegin1 = 0;
//       int iBegin2 = 0;
//       int iEnd1 = 0;
//       int iEnd2 = 0;
      
//       while (iBegin1 < num)
//       {
//          numIterations++;
         
//          //TEST---------------------------------------------------------------------
//          iEnd1 = iBegin1;
//          while( (source[iEnd1] < source[iEnd1 + 1]) && (iEnd1 < num) )
//          {
      
//             iEnd1++;
//          }
//          iBegin2 = iEnd1 + 1;
//          iEnd2 = iBegin2;
//          while( (source[iEnd2] < source[iEnd2 + 1]) && (iEnd2 < num) )
//          {
//             iEnd2++;
//          }


//          //ENDTEST------------------------------------------------------------------
         
//          // for (iEnd1 = iBegin1 + 1; iEnd1 < num && !(source[iEnd1 - 1] > source[iEnd1]); iEnd1++ ) 
//          // {
//          //    //intentionally empty
//          // }
//          // iEnd1--;
//          // iBegin2 = iEnd1 + 1;
         
//          // for (iEnd2 = iBegin2 + 1; iEnd2 < num && !(source[iEnd2 - 1] > source[iEnd2]); iEnd2++ ) 
//          // {
//          //    //intentionally empty
//          // }
//          // iEnd2--;
//          if (iBegin2 < num)
//          {
//             merge(destination,
//                   (source + iBegin1), iEnd1 - iBegin1 + 1,
//                   (source + iBegin2), iEnd2 - iBegin2 + 1, iBegin1);
//          }

//          iBegin1 = iEnd2 + 1;
//       }

//       std::copy(destinationArr, destinationArr+num, sourceArr);

//       // //swap pointers
//       // T * tempP = destination;
//       // destination = source;
//       // source = tempP;
//       // tempP = nullptr;
      
//    }
//    while (numIterations > 1);
   
//    if (array != destinationArr)
//    {
//       for (int i = 0; i < num; i++)
//       {
//          array[i] = destinationArr[i];
//       }
//    }
// }

#endif // SORT_MERGE_H
